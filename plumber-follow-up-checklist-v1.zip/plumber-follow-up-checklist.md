# The 10-Minute Plumber Follow-Up Checklist

A simple daily routine for independent plumbing businesses that want fewer enquiries and quotes to fall through the cracks.

## Every morning — 3 minutes

- [ ] Reply to every new enquiry and state when they can expect the next update.
- [ ] Ask only for the details needed to assess the job: location, issue, timing, and a photo if safe.
- [ ] Record the customer, issue, next action, and due date in one place.

## After sending a quote — 2 minutes

- [ ] Confirm that the quote was sent and explain what it covers.
- [ ] Schedule one polite check-in for two days later.
- [ ] If there is no decision, schedule one final close-the-loop message for day seven.

## After each job — 2 minutes

- [ ] Send a completion note confirming the work done and where to find the invoice or care notes.
- [ ] Record any promised follow-up or unresolved issue.
- [ ] Schedule a review request for the next day—but only if the customer is genuinely satisfied.

## Before finishing the day — 3 minutes

- [ ] Check every promised reply or estimate due today.
- [ ] Move booked, paused, and closed jobs to the correct status.
- [ ] Make sure each open enquiry has one clear next action and date.

## Copy-and-use follow-up message

> Hi [First name], just checking that you received the quote for [job]. Is there anything you’d like changed or explained before deciding?

## Keep the tracker simple

Use these columns in a spreadsheet or job-management tool:

`Customer | Issue | Last contact | Next action | Due date | Status | Notes`

Only add people who contacted or hired the business. Respect opt-outs and applicable privacy and marketing rules. This checklist is an operational aid, not legal advice or a promise of bookings or reviews.

---

Want the full workflow? **The Plumber Follow-Up & Review Kit** includes 10 customizable customer messages, a ready-made tracker, a setup guide, and a personalization worksheet.
